
class ZiggeoConfig:
    def __init__(self):
        self.local = False 
        self.server_api_url = "https://srvapi.ziggeo.com"